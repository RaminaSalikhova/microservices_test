create view pg_stat_xact_sys_tables
            (relid, schemaname, relname, seq_scan, seq_tup_read, idx_scan, idx_tup_fetch, n_tup_ins, n_tup_upd,
             n_tup_del, n_tup_hot_upd)
as
SELECT pg_stat_xact_all_tables.relid,
       pg_stat_xact_all_tables.schemaname,
       pg_stat_xact_all_tables.relname,
       pg_stat_xact_all_tables.seq_scan,
       pg_stat_xact_all_tables.seq_tup_read,
       pg_stat_xact_all_tables.idx_scan,
       pg_stat_xact_all_tables.idx_tup_fetch,
       pg_stat_xact_all_tables.n_tup_ins,
       pg_stat_xact_all_tables.n_tup_upd,
       pg_stat_xact_all_tables.n_tup_del,
       pg_stat_xact_all_tables.n_tup_hot_upd
FROM pg_stat_xact_all_tables
WHERE (pg_stat_xact_all_tables.schemaname = ANY (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
   OR pg_stat_xact_all_tables.schemaname ~ '^pg_toast'::text;

alter table pg_stat_xact_sys_tables
    owner to postgres;

grant select on pg_stat_xact_sys_tables to public;

